import { getDOMRange, getDOMSelection, setDOMRange } from "trix/observers/selection_change_observer"
export { getDOMSelection, getDOMRange, setDOMRange }
