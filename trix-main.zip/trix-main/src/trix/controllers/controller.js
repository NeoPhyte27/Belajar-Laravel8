import "trix/views/object_view"
import BasicObject from "trix/core/basic_object"

export default class Controller extends BasicObject {}
